﻿using AutoMapper;
using BookMyShow.Model;
using BookMyShow.Service;
using BookMyShow.Business;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data;
using System.Linq;


namespace BookMyShow.Controllers
{
    [Route("api/bookings")]
    [ApiController]
    public class BookingController : ControllerBase
    {

        private readonly IBookingService Bookings;
        
        public BookingController(IBookingService bookings)
        {
            Bookings = bookings;
        }

        [HttpGet]
        public List<Booking> GetBookings()
        {
            var bookings = Bookings.GetAllBookings();
            return bookings;
        }

        [HttpPost]
        public void AddBooking(BookingDb booking)
        {
            Bookings.AddBooking(booking);
        }
    }
}
