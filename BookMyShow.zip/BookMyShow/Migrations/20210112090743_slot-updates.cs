﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace BookMyShow.Migrations
{
    public partial class slotupdates : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Slots_Movies_MovieId",
                table: "Slots");

            migrationBuilder.DropIndex(
                name: "IX_Slots_MovieId",
                table: "Slots");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Slots_MovieId",
                table: "Slots",
                column: "MovieId");

            migrationBuilder.AddForeignKey(
                name: "FK_Slots_Movies_MovieId",
                table: "Slots",
                column: "MovieId",
                principalTable: "Movies",
                principalColumn: "MovieId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
