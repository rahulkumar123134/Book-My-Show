﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookMyShow.Model;
using BookMyShow.Service;

namespace WebService.Services
{
    public interface IMovieService
    {
        public List<Movie> GetAllMovies();

        public Movie GetMovieById(int id);
    }
}
