﻿using AutoMapper;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using BookMyShow.Model;
using BookMyShow.Service;
using BookMyShow.Business;
using Microsoft.Extensions.Configuration;
using Microsoft.Data.SqlClient;
using Dapper;

namespace WebService.Services
{
    public class BookingService: IBookingService
    {
        private readonly IDbConnection connection;

        private readonly IMapper mapper;

        public BookingService(IConfiguration configuration, IMapper _mapper)
        {
            connection = new SqlConnection(configuration.GetConnectionString("BookMyShowDb"));
            mapper = _mapper;
        }

        public List<Booking> GetAllBookings()
        {
            var command = "select * from Bookings";
            var bookings = connection.Query<Booking>(command).ToList();
            return bookings;
        }

        public void AddBooking(BookingDb booking)
        {
            var command = "insert into Bookings(UserName,SlotId, PhoneNo, Email)" + "values( @UserName, @SlotId, @PhoneNo, @Email)";
            connection.Execute(command, mapper.Map<Booking>(booking));
        }
    }
}
