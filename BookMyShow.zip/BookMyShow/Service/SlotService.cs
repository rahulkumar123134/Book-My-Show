﻿using AutoMapper;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using BookMyShow.Model;
using BookMyShow.Service;

namespace WebService.Services
{
    public class SlotService : ISlotService
    {
        private readonly IDbConnection connection;

        private readonly IMapper mapper;

        public SlotService(IConfiguration configuration, IMapper _mapper)
        {
            connection = new SqlConnection(configuration.GetConnectionString("BookMyShowDb"));
            mapper = _mapper;
        }
        public List<Slot> GetSlotsById(int id)
        {
            var command = "select * from Slots where Movieid=@id";
            var slots = connection.Query<Slot>(command, new { id = id }).ToList();
            return slots;
        }
    }
}
