﻿using AutoMapper;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using BookMyShow.Model;
using BookMyShow.Service;

namespace WebService.Services
{
    public class MovieService : IMovieService
    {
        private readonly IDbConnection connection;

        private readonly IMapper mapper;

        public MovieService(IConfiguration configuration, IMapper _mapper)
        {
            connection = new SqlConnection(configuration.GetConnectionString("BookMyShowDb"));
            mapper = _mapper;
        }
        public List<Movie> GetAllMovies()
        {
            var command = "select * from Movies";
            var movies = connection.Query<Movie>(command).ToList();
            return movies;
        }

        public Movie GetMovieById(int id)
        {
            var command = "select * from Movies where Movieid=@id";
            Movie movie = connection.Query<Movie>(command, new { id = id }).FirstOrDefault();
            return movie;
        }
    }
}
